package com.stackroute.entity;


public enum UserRoles {

    PLAYER,
    GROUND_OWNER

}
