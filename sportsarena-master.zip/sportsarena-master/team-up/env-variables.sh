export MONGO_DATABASENAME=teamup_db
export MONGO_URI=mongodb://localhost:27017/teamup_db