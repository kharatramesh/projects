// import React,{useState} from "react";
// import "../Assets/css/list.css";
// // import  Product from "../Services/vendor";



// const Card =({product}) =>{
   

// return (
//     <div>
//       <imgs src={product.groundPicture}/>
//        <h4 >{product.groundName}</h4>
//        <h6>{product.city}</h6>
//        <h6>{product.ameneties}</h6>
//        <div className='col-md-10  text-center my-4' ><button className='btn btn-primary btn-sm '>Book Slot</button></div>
//     </div>
// )

// }

// export default Card;
