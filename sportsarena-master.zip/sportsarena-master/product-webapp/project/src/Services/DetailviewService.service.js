// import axios from "axios";

// const baseURL= "http://localhost:3000";
// export function getDetailView( type,groundID, callback, errorcallback) {
//     // const url = `${baseURL}/${type}`;
//     // console.log(url);
//     axios.get(`${baseURL}/${type}?groundId=${gr}`)
//       .then(res => {
//         //do something
//         if (callback != null) {
//           callback(res);
//         }
//       })
//       .catch(err => {
//         // catch error
//         if (errorcallback != null) {
//           errorcallback(err);
//         }
//       })
//   }