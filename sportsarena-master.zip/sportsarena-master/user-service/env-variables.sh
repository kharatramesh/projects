export MONGO_DATABASENAME=userservice_db
export MONGO_URI=mongodb://localhost:27017/userservice_db