package com.stackroute.service;

import com.stackroute.entity.Email;

public interface EmailService {
    void sendEmail(Email emailBody);
}
