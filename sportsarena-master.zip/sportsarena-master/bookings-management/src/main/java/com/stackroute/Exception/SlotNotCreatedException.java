package com.stackroute.Exception;

public class SlotNotCreatedException extends Exception{
    public SlotNotCreatedException(String message) {
        super(message);
    }
}
