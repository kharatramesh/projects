package com.stackroute.Slot.entity;

public enum Status {
    AVAILABLE,
    BOOKED,

    CANCELLED
}
