package com.stackroute.Exception;

public class BookingNotCreated extends Exception{
    public BookingNotCreated(String message) {
        super(message);
    }
}
