export MONGO_DATABASENAME=bookings_db
export MONGO_URI=mongodb://localhost:27017/bookings_db