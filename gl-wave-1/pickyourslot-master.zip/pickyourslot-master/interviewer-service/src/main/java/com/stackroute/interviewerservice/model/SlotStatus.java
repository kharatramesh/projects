package com.stackroute.interviewerservice.model;

public enum SlotStatus {
    Available,
    Booked;

}
