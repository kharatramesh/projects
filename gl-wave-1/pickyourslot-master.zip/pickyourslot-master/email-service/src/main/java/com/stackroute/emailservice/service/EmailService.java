package com.stackroute.emailservice.service;

import com.stackroute.emailservice.model.Email;

public interface EmailService {
    public void sendEmail(Email email);

}
