package com.stackroute.authenticationservice;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationServiceApplicationTests {
//    @Test
//    void contextLoads(){
//
//    }
}
