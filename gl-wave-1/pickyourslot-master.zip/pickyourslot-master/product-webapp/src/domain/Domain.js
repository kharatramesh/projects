import React from 'react'

function Domain() {
    return "https://pickmyslot.stackroute.io/"
}

export default Domain
