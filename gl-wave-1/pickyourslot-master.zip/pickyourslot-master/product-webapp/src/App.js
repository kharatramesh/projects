import "./App.css";

import { Routes, Route } from "react-router-dom";
import TechTracks from "./tech-tracks/Screens/TechTracks";
import Interviewers from "./tech-tracks/Screens/Interviewers";

function App() {
  return <div className="App"></div>;
}

export default App;
