package com.stackroute.pickyourslotwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PickyourslotWebappApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
