package com.stackroute.service;

public interface EmailService {

    boolean sendEmail(String to,String body);
}
