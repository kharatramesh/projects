package com.stackroute.exception;

public class ClientAlreadyPresent extends Exception{

    public ClientAlreadyPresent(String message){
        super(message);
    }
}
