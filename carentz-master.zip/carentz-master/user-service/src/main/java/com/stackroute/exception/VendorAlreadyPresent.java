package com.stackroute.exception;

public class VendorAlreadyPresent extends  Exception{

    public VendorAlreadyPresent(String message){
        super(message);
    }
}
