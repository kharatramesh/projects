package com.stackroute.exception;

public class ClientNotFoundException extends Exception{

    public ClientNotFoundException(String message){
        super(message);
    }
}
