package com.stackroute.exception;

public class VendorNotFoundException extends Exception{

    public VendorNotFoundException(String message){
        super(message);
    }
}
