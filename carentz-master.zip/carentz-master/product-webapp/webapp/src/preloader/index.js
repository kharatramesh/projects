import "./spinner.css";
export default function PreLoader() {
    return(
        <>
            <div className="loading">Loading...</div>
        </>
    )
}