//const baseUrl = 'http://localhost:8080/bookings-management';
const baseUrl = 'https://carentz.stackroute.io/bookings-management';


export const getServerUrl = () => {
  return `${baseUrl}/api/v4`;
};
