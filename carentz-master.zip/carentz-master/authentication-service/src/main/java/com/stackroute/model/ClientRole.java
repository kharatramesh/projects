package com.stackroute.model;

public enum ClientRole {

	CLIENT,
	VENDOR;
}
