package com.stackroute.exception;

public class VehicleNotFoundException extends Exception {
	public VehicleNotFoundException(String message) {
		super(message);
	}

}
