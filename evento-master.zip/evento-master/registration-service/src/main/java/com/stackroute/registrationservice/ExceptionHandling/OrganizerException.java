package com.stackroute.registrationservice.ExceptionHandling;

public class OrganizerException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public OrganizerException(String message) {
		super(message);
	}
	

}
