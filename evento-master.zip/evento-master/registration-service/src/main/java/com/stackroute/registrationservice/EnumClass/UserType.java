package com.stackroute.registrationservice.EnumClass;

public enum UserType {
	User,Organizer;
	
}
